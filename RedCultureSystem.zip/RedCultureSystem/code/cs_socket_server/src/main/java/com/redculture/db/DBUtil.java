package com.redculture.db;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * MySQL 数据库工具类（V3 服务端）
 *
 * 配置文件位置：classpath:db.properties
 * 主要字段：
 *   jdbc.url
 *   jdbc.username
 *   jdbc.password
 *   jdbc.driver
 */
public class DBUtil {

    private static String url;
    private static String username;
    private static String password;
    private static String driver;

    static {
        Properties props = new Properties();
        // 优先读 classpath 下 db.properties
        try (InputStream in = DBUtil.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in != null) {
                props.load(in);
            }
        } catch (IOException e) {
            // 静默处理，下面兜底默认值
        }
        url = props.getProperty("jdbc.url",
                "jdbc:mysql://localhost:3306/redculture_v3?useSSL=false&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true");
        username = props.getProperty("jdbc.username", "root");
        password = props.getProperty("jdbc.password", "123456");
        driver = props.getProperty("jdbc.driver", "com.mysql.cj.jdbc.Driver");
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL 驱动加载失败：" + driver, e);
        }
    }

    /** 获取连接 */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }

    /** 关闭资源 */
    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException ignored) {
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException ignored) {
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ignored) {
            }
        }
    }

    public static void close(Connection conn) {
        close(conn, null, null);
    }

    public static String getUrl() {
        return url;
    }

    public static String getUsername() {
        return username;
    }
}
