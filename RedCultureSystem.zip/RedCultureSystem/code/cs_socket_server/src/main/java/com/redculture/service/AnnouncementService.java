package com.redculture.service;

import com.redculture.dao.AnnouncementDAO;
import com.redculture.pojo.Announcement;

import java.sql.SQLException;
import java.util.List;

/**
 * 公告业务逻辑层
 *
 * 业务规则：
 *   1) 新增/修改时标题不能为空；
 *   2) 查询支持按标题或编号关键字过滤。
 */
public class AnnouncementService {

    private final AnnouncementDAO announcementDAO = new AnnouncementDAO();

    public List<Announcement> list(String keyword) throws SQLException {
        return announcementDAO.list(keyword);
    }

    public Announcement get(int id) throws SQLException {
        Announcement a = announcementDAO.findById(id);
        if (a == null) {
            throw new RuntimeException("公告不存在");
        }
        return a;
    }

    public void add(Announcement a) throws SQLException {
        if (a == null || a.getTitle() == null || a.getTitle().trim().isEmpty()) {
            throw new RuntimeException("公告标题不能为空");
        }
        if (a.getContent() == null) {
            a.setContent("");
        }
        boolean ok = announcementDAO.insert(a);
        if (!ok) {
            throw new RuntimeException("新增公告失败");
        }
    }

    public void update(Announcement a) throws SQLException {
        if (a == null || a.getTitle() == null || a.getTitle().trim().isEmpty()) {
            throw new RuntimeException("公告标题不能为空");
        }
        if (announcementDAO.findById(a.getId()) == null) {
            throw new RuntimeException("公告不存在");
        }
        boolean ok = announcementDAO.update(a);
        if (!ok) {
            throw new RuntimeException("修改公告失败");
        }
    }

    public void delete(int id) throws SQLException {
        if (announcementDAO.findById(id) == null) {
            throw new RuntimeException("公告不存在");
        }
        boolean ok = announcementDAO.delete(id);
        if (!ok) {
            throw new RuntimeException("删除公告失败");
        }
    }
}
