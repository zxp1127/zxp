package com.redculture.service;

import com.redculture.dao.ScenicSpotDAO;
import com.redculture.pojo.ScenicSpot;

import java.sql.SQLException;
import java.util.List;

/**
 * 景点业务逻辑层
 *
 * 业务规则：
 *   1) 新增/修改时景点名不能为空；
 *   2) 查询支持按名称或编号关键字过滤；
 *   3) 热门景点判定由 is_popular 字段控制（管理员维护），排行榜由 CheckinService 生成。
 */
public class ScenicSpotService {

    private final ScenicSpotDAO scenicSpotDAO = new ScenicSpotDAO();

    public List<ScenicSpot> list(String keyword) throws SQLException {
        return scenicSpotDAO.list(keyword);
    }

    public ScenicSpot get(int id) throws SQLException {
        ScenicSpot s = scenicSpotDAO.findById(id);
        if (s == null) {
            throw new RuntimeException("景点不存在");
        }
        return s;
    }

    public void add(ScenicSpot s) throws SQLException {
        if (s == null || s.getName() == null || s.getName().trim().isEmpty()) {
            throw new RuntimeException("景点名称不能为空");
        }
        if (s.getDescription() == null) {
            s.setDescription("");
        }
        if (s.getLocation() == null) {
            s.setLocation("");
        }
        boolean ok = scenicSpotDAO.insert(s);
        if (!ok) {
            throw new RuntimeException("新增景点失败");
        }
    }

    public void update(ScenicSpot s) throws SQLException {
        if (s == null || s.getName() == null || s.getName().trim().isEmpty()) {
            throw new RuntimeException("景点名称不能为空");
        }
        if (scenicSpotDAO.findById(s.getId()) == null) {
            throw new RuntimeException("景点不存在");
        }
        boolean ok = scenicSpotDAO.update(s);
        if (!ok) {
            throw new RuntimeException("修改景点失败");
        }
    }

    public void delete(int id) throws SQLException {
        if (scenicSpotDAO.findById(id) == null) {
            throw new RuntimeException("景点不存在");
        }
        boolean ok = scenicSpotDAO.delete(id);
        if (!ok) {
            throw new RuntimeException("删除景点失败");
        }
    }
}
