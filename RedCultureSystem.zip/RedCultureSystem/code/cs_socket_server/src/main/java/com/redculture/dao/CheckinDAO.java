package com.redculture.dao;

import com.redculture.db.DBUtil;
import com.redculture.pojo.CheckinRecord;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 打卡记录数据访问对象
 *
 * 查询时关联 users / scenic_spots 表填充 username / spotName 冗余字段，便于客户端直接展示。
 */
public class CheckinDAO {

    /** 按 id 查询打卡记录（用于删除前定位所属用户，扣分用） */
    public CheckinRecord findById(int id) throws SQLException {
        String sql = "SELECT id, user_id, spot_id, comment, checkin_time FROM checkin_records WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    CheckinRecord c = new CheckinRecord();
                    c.setId(rs.getInt("id"));
                    c.setUserId(rs.getInt("user_id"));
                    c.setSpotId(rs.getInt("spot_id"));
                    c.setComment(rs.getString("comment"));
                    c.setCheckinTime(rs.getTimestamp("checkin_time"));
                    return c;
                }
            }
        }
        return null;
    }

    /** 新增打卡 */
    public boolean insert(CheckinRecord c) throws SQLException {
        String sql = "INSERT INTO checkin_records (user_id, spot_id, comment) VALUES (?,?,?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, c.getUserId());
            ps.setInt(2, c.getSpotId());
            ps.setString(3, c.getComment());
            return ps.executeUpdate() > 0;
        }
    }

    /** 修改打卡心得 */
    public boolean updateComment(int id, String comment) throws SQLException {
        String sql = "UPDATE checkin_records SET comment = ? WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, comment);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        }
    }

    /** 删除打卡 */
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM checkin_records WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    /** 按用户查询打卡记录 */
    public List<CheckinRecord> listByUser(int userId, String keyword, Integer spotId) throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT r.id, r.user_id, r.spot_id, r.comment, r.checkin_time, " +
                        "u.username, s.name AS spot_name " +
                        "FROM checkin_records r " +
                        "LEFT JOIN users u ON u.id = r.user_id " +
                        "LEFT JOIN scenic_spots s ON s.id = r.spot_id " +
                        "WHERE r.user_id = ?");
        List<Object> args = new ArrayList<>();
        args.add(userId);
        if (spotId != null && spotId > 0) {
            sql.append(" AND r.spot_id = ?");
            args.add(spotId);
        }
        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (s.name LIKE ? OR r.comment LIKE ? OR CAST(r.id AS CHAR) LIKE ?)");
            String k = "%" + keyword.trim() + "%";
            args.add(k);
            args.add(k);
            args.add(k);
        }
        sql.append(" ORDER BY r.checkin_time DESC, r.id DESC");
        return queryList(sql.toString(), args);
    }

    /** 查询全部打卡（管理员） */
    public List<CheckinRecord> listAll(String keyword) throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT r.id, r.user_id, r.spot_id, r.comment, r.checkin_time, " +
                        "u.username, s.name AS spot_name " +
                        "FROM checkin_records r " +
                        "LEFT JOIN users u ON u.id = r.user_id " +
                        "LEFT JOIN scenic_spots s ON s.id = r.spot_id WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (u.username LIKE ? OR s.name LIKE ? OR r.comment LIKE ?)");
            String k = "%" + keyword.trim() + "%";
            args.add(k);
            args.add(k);
            args.add(k);
        }
        sql.append(" ORDER BY r.checkin_time DESC, r.id DESC");
        return queryList(sql.toString(), args);
    }

    /** 热门景点排行榜：景点名 + 打卡次数 */
    public List<Object[]> rankPopularSpots() throws SQLException {
        String sql = "SELECT s.name AS spot_name, COUNT(r.id) AS cnt " +
                "FROM scenic_spots s " +
                "LEFT JOIN checkin_records r ON r.spot_id = s.id " +
                "GROUP BY s.id, s.name " +
                "ORDER BY cnt DESC, s.id ASC";
        List<Object[]> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Object[]{rs.getString("spot_name"), rs.getInt("cnt")});
            }
        }
        return list;
    }

    private List<CheckinRecord> queryList(String sql, List<Object> args) throws SQLException {
        List<CheckinRecord> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < args.size(); i++) {
                ps.setObject(i + 1, args.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    private CheckinRecord mapRow(ResultSet rs) throws SQLException {
        CheckinRecord c = new CheckinRecord();
        c.setId(rs.getInt("id"));
        c.setUserId(rs.getInt("user_id"));
        c.setSpotId(rs.getInt("spot_id"));
        c.setComment(rs.getString("comment"));
        c.setCheckinTime(rs.getTimestamp("checkin_time"));
        c.setUsername(rs.getString("username"));
        c.setSpotName(rs.getString("spot_name"));
        return c;
    }
}
