package com.redculture.dao;

import com.redculture.db.DBUtil;
import com.redculture.pojo.ScenicSpot;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 景点数据访问对象
 */
public class ScenicSpotDAO {

    /** 查询全部，可按名称/编号关键字过滤 */
    public List<ScenicSpot> list(String keyword) throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT id, name, description, location, is_popular, create_time FROM scenic_spots WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (name LIKE ? OR CAST(id AS CHAR) LIKE ?)");
            String k = "%" + keyword.trim() + "%";
            args.add(k);
            args.add(k);
        }
        sql.append(" ORDER BY is_popular DESC, id ASC");
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < args.size(); i++) {
                ps.setObject(i + 1, args.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<ScenicSpot> list = new ArrayList<>();
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
                return list;
            }
        }
    }

    /** 按 id 查询 */
    public ScenicSpot findById(int id) throws SQLException {
        String sql = "SELECT id, name, description, location, is_popular, create_time FROM scenic_spots WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /** 新增 */
    public boolean insert(ScenicSpot s) throws SQLException {
        String sql = "INSERT INTO scenic_spots (name, description, location, is_popular) VALUES (?,?,?,?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getDescription());
            ps.setString(3, s.getLocation());
            ps.setInt(4, s.isPopular() ? 1 : 0);
            return ps.executeUpdate() > 0;
        }
    }

    /** 修改 */
    public boolean update(ScenicSpot s) throws SQLException {
        String sql = "UPDATE scenic_spots SET name = ?, description = ?, location = ?, is_popular = ? WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getDescription());
            ps.setString(3, s.getLocation());
            ps.setInt(4, s.isPopular() ? 1 : 0);
            ps.setInt(5, s.getId());
            return ps.executeUpdate() > 0;
        }
    }

    /** 删除 */
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM scenic_spots WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private ScenicSpot mapRow(ResultSet rs) throws SQLException {
        ScenicSpot s = new ScenicSpot();
        s.setId(rs.getInt("id"));
        s.setName(rs.getString("name"));
        s.setDescription(rs.getString("description"));
        s.setLocation(rs.getString("location"));
        s.setPopular(rs.getInt("is_popular") == 1);
        s.setCreateTime(rs.getTimestamp("create_time"));
        return s;
    }
}
