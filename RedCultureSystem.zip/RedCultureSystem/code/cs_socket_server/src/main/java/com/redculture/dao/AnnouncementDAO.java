package com.redculture.dao;

import com.redculture.db.DBUtil;
import com.redculture.pojo.Announcement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 公告数据访问对象
 */
public class AnnouncementDAO {

    /** 查询全部，可按标题/编号关键字过滤 */
    public List<Announcement> list(String keyword) throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT id, title, content, publisher, create_time FROM announcements WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (title LIKE ? OR CAST(id AS CHAR) LIKE ?)");
            String k = "%" + keyword.trim() + "%";
            args.add(k);
            args.add(k);
        }
        sql.append(" ORDER BY create_time DESC, id DESC");
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < args.size(); i++) {
                ps.setObject(i + 1, args.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Announcement> list = new ArrayList<>();
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
                return list;
            }
        }
    }

    /** 按 id 查询 */
    public Announcement findById(int id) throws SQLException {
        String sql = "SELECT id, title, content, publisher, create_time FROM announcements WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /** 新增 */
    public boolean insert(Announcement a) throws SQLException {
        String sql = "INSERT INTO announcements (title, content, publisher) VALUES (?,?,?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getTitle());
            ps.setString(2, a.getContent());
            ps.setString(3, a.getPublisher());
            return ps.executeUpdate() > 0;
        }
    }

    /** 修改 */
    public boolean update(Announcement a) throws SQLException {
        String sql = "UPDATE announcements SET title = ?, content = ?, publisher = ? WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getTitle());
            ps.setString(2, a.getContent());
            ps.setString(3, a.getPublisher());
            ps.setInt(4, a.getId());
            return ps.executeUpdate() > 0;
        }
    }

    /** 删除 */
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM announcements WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Announcement mapRow(ResultSet rs) throws SQLException {
        Announcement a = new Announcement();
        a.setId(rs.getInt("id"));
        a.setTitle(rs.getString("title"));
        a.setContent(rs.getString("content"));
        a.setPublisher(rs.getString("publisher"));
        a.setCreateTime(rs.getTimestamp("create_time"));
        return a;
    }
}
