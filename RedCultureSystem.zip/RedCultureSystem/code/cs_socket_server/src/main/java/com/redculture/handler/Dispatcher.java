package com.redculture.handler;

import com.redculture.pojo.Announcement;
import com.redculture.pojo.CheckinRecord;
import com.redculture.pojo.ScenicSpot;
import com.redculture.pojo.User;
import com.redculture.protocol.ActionType;
import com.redculture.protocol.Request;
import com.redculture.protocol.Response;
import com.redculture.service.AnnouncementService;
import com.redculture.service.CheckinService;
import com.redculture.service.ScenicSpotService;
import com.redculture.service.UserService;

import java.sql.SQLException;

/**
 * 请求分发器（V3 服务端核心）
 *
 * 作用：
 *   1) 把客户端发来的 Request.action 路由到对应 Service 方法；
 *   2) 把业务异常 / SQL 异常统一包装成 Response.fail，避免异常信息暴露给客户端；
 *   3) 单例无状态，多个 ClientHandler 线程共享，安全并发。
 */
public class Dispatcher {

    private final UserService userService = new UserService();
    private final AnnouncementService announcementService = new AnnouncementService();
    private final ScenicSpotService scenicSpotService = new ScenicSpotService();
    private final CheckinService checkinService = new CheckinService();

    /**
     * 处理一次请求
     */
    public Response dispatch(Request req) {
        if (req == null || req.getAction() == null) {
            return Response.fail("请求为空");
        }
        String action = req.getAction();
        try {
            switch (action) {
                // ---------- 用户模块 ----------
                case ActionType.USER_LOGIN:
                    return Response.ok("登录成功",
                            userService.login(req.getString("username"), req.getString("password")));

                case ActionType.USER_REGISTER:
                    return Response.ok("注册成功",
                            userService.register(req.getString("username"), req.getString("password")));

                case ActionType.USER_UPDATE_PASSWORD:
                    userService.updatePassword(req.getInt("userId"), req.getString("newPassword"));
                    return Response.ok("修改密码成功");

                case ActionType.USER_UPDATE_USERNAME:
                    User updated = userService.updateUsername(req.getInt("userId"), req.getString("newUsername"));
                    return Response.ok("修改用户名成功", updated);

                case ActionType.USER_LIST_ALL:
                    return Response.ok("查询成功", userService.listAll());

                case ActionType.USER_GET_BY_ID:
                    return Response.ok("查询成功", userService.getById(req.getInt("userId")));

                // ---------- 公告模块 ----------
                case ActionType.ANN_LIST:
                    return Response.ok("查询成功", announcementService.list(req.getString("keyword")));

                case ActionType.ANN_GET:
                    return Response.ok("查询成功", announcementService.get(req.getInt("id")));

                case ActionType.ANN_ADD:
                    Announcement a = new Announcement();
                    a.setTitle(req.getString("title"));
                    a.setContent(req.getString("content"));
                    a.setPublisher(req.getString("publisher"));
                    announcementService.add(a);
                    return Response.ok("新增公告成功");

                case ActionType.ANN_UPDATE:
                    Announcement au = new Announcement();
                    au.setId(req.getInt("id"));
                    au.setTitle(req.getString("title"));
                    au.setContent(req.getString("content"));
                    au.setPublisher(req.getString("publisher"));
                    announcementService.update(au);
                    return Response.ok("修改公告成功");

                case ActionType.ANN_DELETE:
                    announcementService.delete(req.getInt("id"));
                    return Response.ok("删除公告成功");

                // ---------- 景点模块 ----------
                case ActionType.SPOT_LIST:
                    return Response.ok("查询成功", scenicSpotService.list(req.getString("keyword")));

                case ActionType.SPOT_GET:
                    return Response.ok("查询成功", scenicSpotService.get(req.getInt("id")));

                case ActionType.SPOT_ADD:
                    ScenicSpot sAdd = new ScenicSpot();
                    sAdd.setName(req.getString("name"));
                    sAdd.setDescription(req.getString("description"));
                    sAdd.setLocation(req.getString("location"));
                    sAdd.setPopular(req.getBool("popular"));
                    scenicSpotService.add(sAdd);
                    return Response.ok("新增景点成功");

                case ActionType.SPOT_UPDATE:
                    ScenicSpot sUp = new ScenicSpot();
                    sUp.setId(req.getInt("id"));
                    sUp.setName(req.getString("name"));
                    sUp.setDescription(req.getString("description"));
                    sUp.setLocation(req.getString("location"));
                    sUp.setPopular(req.getBool("popular"));
                    scenicSpotService.update(sUp);
                    return Response.ok("修改景点成功");

                case ActionType.SPOT_DELETE:
                    scenicSpotService.delete(req.getInt("id"));
                    return Response.ok("删除景点成功");

                // ---------- 打卡模块 ----------
                case ActionType.CHECKIN_ADD:
                    checkinService.addCheckin(req.getInt("userId"), req.getInt("spotId"), req.getString("comment"));
                    return Response.ok("打卡成功，积分 +1");

                case ActionType.CHECKIN_UPDATE_COMMENT:
                    checkinService.updateComment(req.getInt("id"), req.getString("comment"));
                    return Response.ok("修改心得成功");

                case ActionType.CHECKIN_DELETE:
                    checkinService.deleteCheckin(req.getInt("id"));
                    return Response.ok("删除打卡成功，积分 -1");

                case ActionType.CHECKIN_LIST_BY_USER:
                    Integer spotId = req.get("spotId") == null ? null : req.getInt("spotId");
                    return Response.ok("查询成功",
                            checkinService.listByUser(req.getInt("userId"), req.getString("keyword"), spotId));

                case ActionType.CHECKIN_LIST_ALL:
                    return Response.ok("查询成功", checkinService.listAll(req.getString("keyword")));

                case ActionType.CHECKIN_RANK:
                    return Response.ok("查询成功", checkinService.rankPopularSpots());

                default:
                    return Response.fail("未知动作：" + action);
            }
        } catch (RuntimeException re) {
            // 业务异常：返回给客户端可读的中文提示
            return Response.fail(re.getMessage() == null ? "业务处理失败" : re.getMessage());
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Response.fail("数据库异常：" + sqle.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return Response.fail("系统异常：" + e.getMessage());
        }
    }
}
