package com.redculture.dao;

import com.redculture.db.DBUtil;
import com.redculture.pojo.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 用户数据访问对象
 * 字段：id / username / password / role / points / create_time
 */
public class UserDAO {

    /** 按用户名查询（用于登录、查重） */
    public User findByUsername(String username) throws SQLException {
        String sql = "SELECT id, username, password, role, points, create_time FROM users WHERE username = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /** 按 id 查询 */
    public User findById(int id) throws SQLException {
        String sql = "SELECT id, username, password, role, points, create_time FROM users WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /** 查询全部用户 */
    public List<User> listAll() throws SQLException {
        String sql = "SELECT id, username, password, role, points, create_time FROM users ORDER BY id";
        List<User> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    /** 新增用户 */
    public boolean insert(User u) throws SQLException {
        String sql = "INSERT INTO users (username, password, role, points) VALUES (?,?,?,?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getRole() == null ? "user" : u.getRole());
            ps.setInt(4, u.getPoints());
            return ps.executeUpdate() > 0;
        }
    }

    /** 修改密码 */
    public boolean updatePassword(int id, String newPassword) throws SQLException {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newPassword);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        }
    }

    /** 修改用户名 */
    public boolean updateUsername(int id, String newUsername) throws SQLException {
        String sql = "UPDATE users SET username = ? WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newUsername);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        }
    }

    /** 修改积分（增量，可为负数） */
    public boolean addPoints(int id, int delta) throws SQLException {
        String sql = "UPDATE users SET points = GREATEST(points + ?, 0) WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, delta);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        }
    }

    private User mapRow(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setUsername(rs.getString("username"));
        u.setPassword(rs.getString("password"));
        u.setRole(rs.getString("role"));
        u.setPoints(rs.getInt("points"));
        u.setCreateTime(rs.getTimestamp("create_time"));
        return u;
    }
}
