package com.redculture.ui;

import com.redculture.net.NetUtil;
import com.redculture.pojo.User;
import com.redculture.protocol.ActionType;
import com.redculture.protocol.Request;
import com.redculture.protocol.Response;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import java.awt.GridLayout;

/**
 * 个人信息面板
 *
 * 功能：
 *   1) 展示当前用户名、角色、积分；
 *   2) 修改用户名（重名校验由服务端处理）；
 *   3) 修改密码；
 *   4) 修改成功后回调主窗口刷新标题栏。
 */
public class UserPanel extends JPanel {

    private final User currentUser;
    private final Runnable afterUsernameChanged;
    private final JTextField usernameLabel;
    private final JLabel roleLabel;
    private final JLabel pointsLabel;

    public UserPanel(User user, Runnable afterUsernameChanged) {
        this.currentUser = user;
        this.afterUsernameChanged = afterUsernameChanged;
        setLayout(new java.awt.BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JPanel info = new JPanel(new GridLayout(3, 2, 10, 10));
        info.add(new JLabel("用户名："));
        usernameLabel = new JTextField(currentUser.getUsername());
        usernameLabel.setEditable(false);
        info.add(usernameLabel);
        info.add(new JLabel("角色："));
        roleLabel = new JLabel(currentUser.isAdmin() ? "管理员" : "普通用户");
        info.add(roleLabel);
        info.add(new JLabel("学习积分："));
        pointsLabel = new JLabel(String.valueOf(currentUser.getPoints()));
        info.add(pointsLabel);
        add(info, java.awt.BorderLayout.NORTH);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 20));
        JButton changeName = new JButton("修改用户名");
        changeName.addActionListener(e -> changeUsername());
        btnPanel.add(changeName);
        JButton changePwd = new JButton("修改密码");
        changePwd.addActionListener(e -> changePassword());
        btnPanel.add(changePwd);
        add(btnPanel, java.awt.BorderLayout.CENTER);
    }

    private void changeUsername() {
        JTextField newName = new JTextField(currentUser.getUsername(), 15);
        JPanel form = new JPanel();
        form.add(new JLabel("新用户名："));
        form.add(newName);
        int result = JOptionPane.showConfirmDialog(this, form, "修改用户名",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) {
            return;
        }
        String name = newName.getText().trim();
        if (name.isEmpty()) {
            UIUtil.warn(this, "用户名不能为空");
            return;
        }
        if (name.equals(currentUser.getUsername())) {
            UIUtil.warn(this, "新用户名与当前一致，无需修改");
            return;
        }
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.USER_UPDATE_USERNAME)
                    .param("userId", currentUser.getId())
                    .param("newUsername", name);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return (User) resp.getData();
        }, updated -> {
            currentUser.setUsername(updated.getUsername());
            usernameLabel.setText(updated.getUsername());
            UIUtil.info(this, "修改用户名成功");
            if (afterUsernameChanged != null) {
                afterUsernameChanged.run();
            }
        });
    }

    private void changePassword() {
        JPasswordField oldPwd = new JPasswordField(15);
        JPasswordField newPwd = new JPasswordField(15);
        JPasswordField confirmPwd = new JPasswordField(15);
        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));
        form.add(new JLabel("原密码："));
        form.add(oldPwd);
        form.add(new JLabel("新密码："));
        form.add(newPwd);
        form.add(new JLabel("确认新密码："));
        form.add(confirmPwd);
        int result = JOptionPane.showConfirmDialog(this, form, "修改密码",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) {
            return;
        }
        String oldP = new String(oldPwd.getPassword()).trim();
        String newP = new String(newPwd.getPassword()).trim();
        String confirm = new String(confirmPwd.getPassword()).trim();
        if (!oldP.equals(currentUser.getPassword())) {
            UIUtil.warn(this, "原密码不正确");
            return;
        }
        if (newP.isEmpty()) {
            UIUtil.warn(this, "新密码不能为空");
            return;
        }
        if (!newP.equals(confirm)) {
            UIUtil.warn(this, "两次输入的新密码不一致");
            return;
        }
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.USER_UPDATE_PASSWORD)
                    .param("userId", currentUser.getId())
                    .param("newPassword", newP);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return resp;
        }, r -> {
            currentUser.setPassword(newP);
            UIUtil.info(this, "修改密码成功");
        });
    }

    /** 主窗口切回时调用，刷新积分显示 */
    public void refreshPoints() {
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.USER_GET_BY_ID)
                    .param("userId", currentUser.getId());
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return (User) resp.getData();
        }, u -> {
            currentUser.setPoints(u.getPoints());
            pointsLabel.setText(String.valueOf(currentUser.getPoints()));
        });
    }
}
