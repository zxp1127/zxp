package com.redculture.ui;

import com.redculture.net.NetUtil;
import com.redculture.pojo.Announcement;
import com.redculture.pojo.User;
import com.redculture.protocol.ActionType;
import com.redculture.protocol.Request;
import com.redculture.protocol.Response;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 公告面板
 *
 * 功能：
 *   1) JTable 列表展示；
 *   2) 按标题或编号关键字搜索过滤；
 *   3) 管理员额外提供新增 / 修改 / 删除（弹窗表单）；
 *   4) 任意用户双击行查看公告全文。
 */
public class AnnouncementPanel extends JPanel {

    private static final SimpleDateFormat DATE_FMT = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    private final User currentUser;
    private final DefaultTableModel tableModel;
    private final JTable table;
    private final JTextField keywordField;

    public AnnouncementPanel(User user) {
        this.currentUser = user;
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        // ===== 顶部搜索/操作栏 =====
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        top.add(new JLabel("关键字："));
        keywordField = new JTextField(15);
        top.add(keywordField);
        JButton searchBtn = new JButton("搜索");
        searchBtn.addActionListener(e -> refresh());
        top.add(searchBtn);
        JButton resetBtn = new JButton("重置");
        resetBtn.addActionListener(e -> {
            keywordField.setText("");
            refresh();
        });
        top.add(resetBtn);
        top.add(new JLabel("    "));
        JButton viewBtn = new JButton("查看全文");
        viewBtn.addActionListener(e -> viewSelected());
        top.add(viewBtn);

        // 管理员按钮
        if (currentUser.isAdmin()) {
            JButton addBtn = new JButton("新增公告");
            addBtn.addActionListener(e -> showEditDialog(null));
            top.add(addBtn);
            JButton editBtn = new JButton("修改");
            editBtn.addActionListener(e -> {
                Announcement selected = selectedAnnouncement();
                if (selected != null) {
                    showEditDialog(selected);
                }
            });
            top.add(editBtn);
            JButton delBtn = new JButton("删除");
            delBtn.addActionListener(e -> deleteSelected());
            top.add(delBtn);
        }
        add(top, BorderLayout.NORTH);

        // ===== 表格 =====
        String[] cols = {"编号", "标题", "发布人", "发布时间"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(26);
        table.getTableHeader().setReorderingAllowed(false);
        // 双击查看全文
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() >= 2) {
                    viewSelected();
                }
            }
        });
        add(new JScrollPane(table), BorderLayout.CENTER);

        refresh();
    }

    /** 刷新数据 */
    public void refresh() {
        String keyword = keywordField.getText().trim();
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.ANN_LIST).param("keyword", keyword);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            @SuppressWarnings("unchecked")
            List<Announcement> list = (List<Announcement>) resp.getData();
            return list;
        }, this::renderTable);
    }

    private void renderTable(List<Announcement> list) {
        tableModel.setRowCount(0);
        if (list == null) {
            return;
        }
        for (Announcement a : list) {
            tableModel.addRow(new Object[]{
                    a.getId(),
                    a.getTitle(),
                    a.getPublisher(),
                    formatTime(a.getCreateTime())
            });
        }
    }

    private Announcement selectedAnnouncement() {
        int row = table.getSelectedRow();
        if (row < 0) {
            UIUtil.warn(this, "请先选择一行");
            return null;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        String title = (String) tableModel.getValueAt(row, 1);
        String publisher = (String) tableModel.getValueAt(row, 2);
        Announcement a = new Announcement();
        a.setId(id);
        a.setTitle(title);
        a.setPublisher(publisher);
        return a;
    }

    /** 弹窗查看全文 */
    private void viewSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            UIUtil.warn(this, "请先选择一行");
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.ANN_GET).param("id", id);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return (Announcement) resp.getData();
        }, a -> {
            JTextArea area = new JTextArea(12, 40);
            area.setEditable(false);
            area.setLineWrap(true);
            area.setWrapStyleWord(true);
            area.setText("【公告编号】" + a.getId() + "\n"
                    + "【标题】" + a.getTitle() + "\n"
                    + "【发布人】" + a.getPublisher() + "\n"
                    + "【发布时间】" + formatTime(a.getCreateTime()) + "\n"
                    + "------------------------------------\n"
                    + (a.getContent() == null ? "" : a.getContent()));
            JOptionPane.showMessageDialog(this, new JScrollPane(area),
                    "公告详情", JOptionPane.PLAIN_MESSAGE);
        });
    }

    /** 新增 / 修改 弹窗 */
    private void showEditDialog(Announcement existing) {
        boolean isUpdate = existing != null;
        JTextField titleField = new JTextField(20);
        JTextArea contentArea = new JTextArea(8, 20);
        contentArea.setLineWrap(true);
        JTextField publisherField = new JTextField(currentUser.getUsername(), 10);
        publisherField.setEditable(false);

        if (isUpdate) {
            titleField.setText(existing.getTitle());
            publisherField.setText(existing.getPublisher());
            // 回填内容
            UIUtil.runAsync(this, () -> {
                Request req = new Request(ActionType.ANN_GET).param("id", existing.getId());
                Response resp = NetUtil.send(req);
                if (!resp.isSuccess()) {
                    throw new RuntimeException(resp.getMessage());
                }
                return (Announcement) resp.getData();
            }, a -> contentArea.setText(a.getContent()));
        }

        JPanel form = new JPanel(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
        gbc.insets = new java.awt.Insets(4, 4, 4, 4);
        gbc.anchor = java.awt.GridBagConstraints.WEST;
        gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        form.add(new JLabel("标题："), gbc);
        gbc.gridx = 1;
        form.add(titleField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        form.add(new JLabel("发布人："), gbc);
        gbc.gridx = 1;
        form.add(publisherField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = java.awt.GridBagConstraints.NORTHWEST;
        form.add(new JLabel("内容："), gbc);
        gbc.gridx = 1;
        form.add(new JScrollPane(contentArea), gbc);

        int result = JOptionPane.showConfirmDialog(this, form,
                isUpdate ? "修改公告" : "新增公告",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        String title = titleField.getText().trim();
        String content = contentArea.getText().trim();
        String publisher = publisherField.getText().trim();
        if (title.isEmpty()) {
            UIUtil.warn(this, "标题不能为空");
            return;
        }
        UIUtil.runAsync(this, () -> {
            Request req;
            if (isUpdate) {
                req = new Request(ActionType.ANN_UPDATE)
                        .param("id", existing.getId())
                        .param("title", title)
                        .param("content", content)
                        .param("publisher", publisher);
            } else {
                req = new Request(ActionType.ANN_ADD)
                        .param("title", title)
                        .param("content", content)
                        .param("publisher", publisher);
            }
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return resp;
        }, r -> {
            UIUtil.info(this, isUpdate ? "修改成功" : "新增成功");
            refresh();
        });
    }

    private void deleteSelected() {
        Announcement selected = selectedAnnouncement();
        if (selected == null) {
            return;
        }
        if (!UIUtil.confirm(this, "确定删除公告：" + selected.getTitle() + " ?")) {
            return;
        }
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.ANN_DELETE).param("id", selected.getId());
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return resp;
        }, r -> {
            UIUtil.info(this, "删除成功");
            refresh();
        });
    }

    private String formatTime(Date date) {
        return date == null ? "" : DATE_FMT.format(date);
    }
}
