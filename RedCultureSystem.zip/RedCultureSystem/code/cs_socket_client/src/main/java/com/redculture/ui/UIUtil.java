package com.redculture.ui;

import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import java.awt.Component;
import java.util.function.Consumer;

/**
 * Swing 通用工具类
 *
 * 主要作用：
 *   1) 提供弹窗提示（信息/警告/错误）；
 *   2) 包装 SwingWorker 简化异步查询写法，避免 UI 假死；
 *   3) 统一异常处理。
 */
public final class UIUtil {

    private UIUtil() {
    }

    public static void info(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "提示", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void warn(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "警告", JOptionPane.WARNING_MESSAGE);
    }

    public static void error(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "错误", JOptionPane.ERROR_MESSAGE);
    }

    public static boolean confirm(Component parent, String msg) {
        return JOptionPane.showConfirmDialog(parent, msg, "确认",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    /**
     * 异步执行后台任务：在子线程跑 background，结果回到 EDT 处理。
     * 失败时弹窗显示异常信息。
     *
     * @param parent    父组件（用于弹窗）
     * @param task      后台任务（网络/数据库）
     * @param onSuccess 成功回调（EDT 内执行）
     * @param <T>       结果类型
     */
    public static <T> void runAsync(Component parent,
                                    AsyncSupplier<T> task,
                                    Consumer<T> onSuccess) {
        runAsync(parent, task, onSuccess, null);
    }

    public static <T> void runAsync(Component parent,
                                    AsyncSupplier<T> task,
                                    Consumer<T> onSuccess,
                                    Runnable onFinally) {
        SwingWorker<T, Void> worker = new SwingWorker<T, Void>() {
            @Override
            protected T doInBackground() throws Exception {
                return task.get();
            }

            @Override
            protected void done() {
                try {
                    T t = get();
                    if (onSuccess != null) {
                        onSuccess.accept(t);
                    }
                } catch (Exception e) {
                    Throwable cause = e.getCause() == null ? e : e.getCause();
                    error(parent, cause.getMessage() == null ? "操作失败" : cause.getMessage());
                } finally {
                    if (onFinally != null) {
                        onFinally.run();
                    }
                }
            }
        };
        worker.execute();
    }

    @FunctionalInterface
    public interface AsyncSupplier<T> {
        T get() throws Exception;
    }
}
