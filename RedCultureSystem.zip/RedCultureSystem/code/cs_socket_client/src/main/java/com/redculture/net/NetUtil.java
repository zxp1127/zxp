package com.redculture.net;

import com.redculture.protocol.Request;
import com.redculture.protocol.Response;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Properties;

/**
 * 网络通信工具类（V3 客户端）
 *
 * 职责：
 *   1) 单例管理与服务端的长连接；
 *   2) 提供 send(Request) 同步阻塞返回 Response；
 *   3) 连接断开时自动重连一次；
 *   4) 通过 classpath:client.properties 配置服务端 host/port。
 */
public class NetUtil {

    private static String host;
    private static int port;

    static {
        Properties props = new Properties();
        try {
            //noinspection ConstantConditions
            if (NetUtil.class.getClassLoader().getResourceAsStream("client.properties") != null) {
                props.load(NetUtil.class.getClassLoader().getResourceAsStream("client.properties"));
            }
        } catch (IOException ignored) {
        }
        host = props.getProperty("server.host", "127.0.0.1");
        port = Integer.parseInt(props.getProperty("server.port", "8088"));
    }

    private static Socket socket;
    private static ObjectOutputStream out;
    private static ObjectInputStream in;

    private NetUtil() {
    }

    /** 获取/建立连接 */
    public static synchronized void connect() throws IOException {
        if (isConnected()) {
            return;
        }
        socket = new Socket(host, port);
        out = new ObjectOutputStream(socket.getOutputStream());
        out.flush();
        in = new ObjectInputStream(socket.getInputStream());
    }

    /** 是否已连接 */
    public static synchronized boolean isConnected() {
        return socket != null && !socket.isClosed() && socket.isConnected();
    }

    /**
     * 发送请求并等待响应
     */
    public static synchronized Response send(Request req) throws IOException {
        if (!isConnected()) {
            connect();
        }
        try {
            out.writeObject(req);
            out.reset();
            out.flush();
            return (Response) in.readObject();
        } catch (ClassNotFoundException cnf) {
            throw new IOException("反序列化失败：" + cnf.getMessage(), cnf);
        } catch (IOException io) {
            // 连接已断开，尝试一次重连后重发
            closeQuiet();
            connect();
            out.writeObject(req);
            out.reset();
            out.flush();
            try {
                return (Response) in.readObject();
            } catch (ClassNotFoundException cnf2) {
                throw new IOException("反序列化失败：" + cnf2.getMessage(), cnf2);
            }
        }
    }

    /** 关闭连接 */
    public static synchronized void close() {
        closeQuiet();
    }

    private static void closeQuiet() {
        try {
            if (in != null) {
                in.close();
            }
        } catch (IOException ignored) {
        }
        try {
            if (out != null) {
                out.close();
            }
        } catch (IOException ignored) {
        }
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (IOException ignored) {
        }
        socket = null;
        out = null;
        in = null;
    }

    public static String getHost() {
        return host;
    }

    public static int getPort() {
        return port;
    }
}
