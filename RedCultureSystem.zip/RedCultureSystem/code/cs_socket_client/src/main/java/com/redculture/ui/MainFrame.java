package com.redculture.ui;

import com.redculture.net.NetUtil;
import com.redculture.pojo.User;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import java.awt.BorderLayout;
import java.awt.Font;

/**
 * 主窗口
 *
 * 作用：
 *   1) 标题栏展示当前用户名、学习积分；
 *   2) 顶部用 JTabbedPane 组织各业务面板；
 *   3) 切换 tab 时刷新对应面板，保证数据最新；
 *   4) 管理员才显示用户管理 tab；
 *   5) 关闭窗口时断开网络连接。
 */
public class MainFrame extends JFrame {

    private final User currentUser;
    private final JLabel statusBar;
    private AnnouncementPanel announcementPanel;
    private ScenicSpotPanel scenicSpotPanel;
    private CheckinPanel checkinPanel;
    private RankPanel rankPanel;
    private UserPanel userPanel;
    private UserListPanel userListPanel;

    public MainFrame(User user) {
        this.currentUser = user;
        setTitle("红色文化打卡系统 V3 - C/S 可视化联网版");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        // 顶部红色标题区
        JPanel banner = new JPanel(new BorderLayout());
        banner.setBackground(new java.awt.Color(0xB22222));
        banner.setPreferredSize(new java.awt.Dimension(900, 50));
        JLabel bannerLabel = new JLabel("  红色文化打卡系统", SwingConstants.LEFT);
        bannerLabel.setFont(new Font("微软雅黑", Font.BOLD, 18));
        bannerLabel.setForeground(java.awt.Color.WHITE);
        banner.add(bannerLabel, BorderLayout.WEST);

        statusBar = new JLabel("  当前用户：" + currentUser.getUsername()
                + "  |  角色：" + (currentUser.isAdmin() ? "管理员" : "普通用户")
                + "  |  学习积分：" + currentUser.getPoints() + "  ");
        statusBar.setFont(new Font("微软雅黑", Font.PLAIN, 13));
        statusBar.setForeground(java.awt.Color.WHITE);
        banner.add(statusBar, BorderLayout.EAST);
        root.add(banner, BorderLayout.NORTH);

        // 选项卡
        JTabbedPane tabs = new JTabbedPane();
        announcementPanel = new AnnouncementPanel(currentUser);
        tabs.addTab("公告", announcementPanel);

        scenicSpotPanel = new ScenicSpotPanel(currentUser);
        tabs.addTab("景点", scenicSpotPanel);

        checkinPanel = new CheckinPanel(currentUser);
        tabs.addTab("打卡记录", checkinPanel);

        rankPanel = new RankPanel(currentUser);
        tabs.addTab("排行榜", rankPanel);

        userPanel = new UserPanel(currentUser, this::refreshHeader);
        tabs.addTab("个人信息", userPanel);

        // 管理员额外显示用户管理
        if (currentUser.isAdmin()) {
            userListPanel = new UserListPanel();
            tabs.addTab("用户管理", userListPanel);
        }
        // 切换 tab 时刷新当前面板
        tabs.addChangeListener((ChangeEvent e) -> {
            int idx = tabs.getSelectedIndex();
            String title = tabs.getTitleAt(idx);
            switch (title) {
                case "公告":
                    announcementPanel.refresh();
                    break;
                case "景点":
                    scenicSpotPanel.refresh();
                    break;
                case "打卡记录":
                    checkinPanel.refresh();
                    break;
                case "排行榜":
                    rankPanel.refresh();
                    break;
                case "个人信息":
                    userPanel.refreshPoints();
                    break;
                case "用户管理":
                    if (userListPanel != null) {
                        userListPanel.refresh();
                    }
                    break;
                default:
                    break;
            }
            refreshHeader();
        });

        tabs.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        root.add(tabs, BorderLayout.CENTER);

        setContentPane(root);
    }

    /** 刷新顶部标题栏 */
    private void refreshHeader() {
        statusBar.setText("  当前用户：" + currentUser.getUsername()
                + "  |  角色：" + (currentUser.isAdmin() ? "管理员" : "普通用户")
                + "  |  学习积分：" + currentUser.getPoints() + "  ");
    }

    @Override
    public void dispose() {
        try {
            NetUtil.close();
        } catch (Exception ignored) {
        }
        super.dispose();
        // 关闭主窗口后退出程序
        SwingUtilities.invokeLater(() -> System.exit(0));
    }
}
