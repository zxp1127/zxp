package com.redculture.ui;

import com.redculture.net.NetUtil;
import com.redculture.pojo.ScenicSpot;
import com.redculture.pojo.User;
import com.redculture.protocol.ActionType;
import com.redculture.protocol.Request;
import com.redculture.protocol.Response;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 景点面板
 *
 * 功能：
 *   1) JTable 展示景点信息；
 *   2) 按景点名称或编号搜索；
 *   3) 热门标记列直接展示；
 *   4) 管理员额外提供新增 / 修改 / 删除。
 */
public class ScenicSpotPanel extends JPanel {

    private static final SimpleDateFormat DATE_FMT = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    private final User currentUser;
    private final DefaultTableModel tableModel;
    private final JTable table;
    private final JTextField keywordField;

    public ScenicSpotPanel(User user) {
        this.currentUser = user;
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        top.add(new JLabel("关键字："));
        keywordField = new JTextField(15);
        top.add(keywordField);
        JButton searchBtn = new JButton("搜索");
        searchBtn.addActionListener(e -> refresh());
        top.add(searchBtn);
        JButton resetBtn = new JButton("重置");
        resetBtn.addActionListener(e -> {
            keywordField.setText("");
            refresh();
        });
        top.add(resetBtn);
        top.add(new JLabel("    "));

        JButton viewBtn = new JButton("查看详情");
        viewBtn.addActionListener(e -> viewSelected());
        top.add(viewBtn);

        if (currentUser.isAdmin()) {
            JButton addBtn = new JButton("新增景点");
            addBtn.addActionListener(e -> showEditDialog(null));
            top.add(addBtn);
            JButton editBtn = new JButton("修改");
            editBtn.addActionListener(e -> {
                ScenicSpot selected = selectedSpot();
                if (selected != null) {
                    showEditDialog(selected);
                }
            });
            top.add(editBtn);
            JButton delBtn = new JButton("删除");
            delBtn.addActionListener(e -> deleteSelected());
            top.add(delBtn);
        }
        add(top, BorderLayout.NORTH);

        String[] cols = {"编号", "名称", "位置", "是否热门", "录入时间"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(26);
        table.getTableHeader().setReorderingAllowed(false);
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() >= 2) {
                    viewSelected();
                }
            }
        });
        add(new JScrollPane(table), BorderLayout.CENTER);

        refresh();
    }

    public void refresh() {
        String keyword = keywordField.getText().trim();
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.SPOT_LIST).param("keyword", keyword);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            @SuppressWarnings("unchecked")
            List<ScenicSpot> list = (List<ScenicSpot>) resp.getData();
            return list;
        }, this::renderTable);
    }

    private void renderTable(List<ScenicSpot> list) {
        tableModel.setRowCount(0);
        if (list == null) {
            return;
        }
        for (ScenicSpot s : list) {
            tableModel.addRow(new Object[]{
                    s.getId(),
                    s.getName(),
                    s.getLocation(),
                    s.isPopular() ? "★ 热门" : "—",
                    formatTime(s.getCreateTime())
            });
        }
    }

    private ScenicSpot selectedSpot() {
        int row = table.getSelectedRow();
        if (row < 0) {
            UIUtil.warn(this, "请先选择一行");
            return null;
        }
        ScenicSpot s = new ScenicSpot();
        s.setId((int) tableModel.getValueAt(row, 0));
        s.setName((String) tableModel.getValueAt(row, 1));
        s.setLocation((String) tableModel.getValueAt(row, 2));
        s.setPopular("★ 热门".equals(tableModel.getValueAt(row, 3)));
        return s;
    }

    private void viewSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            UIUtil.warn(this, "请先选择一行");
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.SPOT_GET).param("id", id);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return (ScenicSpot) resp.getData();
        }, s -> {
            JTextArea area = new JTextArea(12, 40);
            area.setEditable(false);
            area.setLineWrap(true);
            area.setWrapStyleWord(true);
            area.setText("【景点编号】" + s.getId() + "\n"
                    + "【名称】" + s.getName() + "\n"
                    + "【位置】" + (s.getLocation() == null ? "" : s.getLocation()) + "\n"
                    + "【是否热门】" + (s.isPopular() ? "是" : "否") + "\n"
                    + "------------------------------------\n"
                    + (s.getDescription() == null ? "" : s.getDescription()));
            JOptionPane.showMessageDialog(this, new JScrollPane(area),
                    "景点详情", JOptionPane.PLAIN_MESSAGE);
        });
    }

    private void showEditDialog(ScenicSpot existing) {
        boolean isUpdate = existing != null;
        JTextField nameField = new JTextField(20);
        JTextField locationField = new JTextField(20);
        JTextArea descArea = new JTextArea(6, 20);
        descArea.setLineWrap(true);
        JCheckBox popularBox = new JCheckBox("热门景点");

        if (isUpdate) {
            nameField.setText(existing.getName());
            locationField.setText(existing.getLocation() == null ? "" : existing.getLocation());
            popularBox.setSelected(existing.isPopular());
            // 回填描述
            UIUtil.runAsync(this, () -> {
                Request req = new Request(ActionType.SPOT_GET).param("id", existing.getId());
                Response resp = NetUtil.send(req);
                if (!resp.isSuccess()) {
                    throw new RuntimeException(resp.getMessage());
                }
                return (ScenicSpot) resp.getData();
            }, s -> descArea.setText(s.getDescription()));
        }

        JPanel form = new JPanel(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
        gbc.insets = new java.awt.Insets(4, 4, 4, 4);
        gbc.anchor = java.awt.GridBagConstraints.WEST;
        gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        form.add(new JLabel("名称："), gbc);
        gbc.gridx = 1;
        form.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        form.add(new JLabel("位置："), gbc);
        gbc.gridx = 1;
        form.add(locationField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        form.add(popularBox, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = java.awt.GridBagConstraints.NORTHWEST;
        form.add(new JLabel("描述："), gbc);
        gbc.gridx = 1;
        form.add(new JScrollPane(descArea), gbc);

        int result = JOptionPane.showConfirmDialog(this, form,
                isUpdate ? "修改景点" : "新增景点",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) {
            return;
        }
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            UIUtil.warn(this, "名称不能为空");
            return;
        }
        UIUtil.runAsync(this, () -> {
            Request req;
            if (isUpdate) {
                req = new Request(ActionType.SPOT_UPDATE)
                        .param("id", existing.getId())
                        .param("name", name)
                        .param("description", descArea.getText().trim())
                        .param("location", locationField.getText().trim())
                        .param("popular", popularBox.isSelected());
            } else {
                req = new Request(ActionType.SPOT_ADD)
                        .param("name", name)
                        .param("description", descArea.getText().trim())
                        .param("location", locationField.getText().trim())
                        .param("popular", popularBox.isSelected());
            }
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return resp;
        }, r -> {
            UIUtil.info(this, isUpdate ? "修改成功" : "新增成功");
            refresh();
        });
    }

    private void deleteSelected() {
        ScenicSpot selected = selectedSpot();
        if (selected == null) {
            return;
        }
        if (!UIUtil.confirm(this, "确定删除景点：" + selected.getName() + " ?\n该景点下的打卡记录将一并删除。")) {
            return;
        }
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.SPOT_DELETE).param("id", selected.getId());
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return resp;
        }, r -> {
            UIUtil.info(this, "删除成功");
            refresh();
        });
    }

    private String formatTime(Date date) {
        return date == null ? "" : DATE_FMT.format(date);
    }
}
