package com.redculture.ui;

import com.redculture.net.NetUtil;
import com.redculture.pojo.User;
import com.redculture.protocol.ActionType;
import com.redculture.protocol.Request;
import com.redculture.protocol.Response;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

/**
 * 登录注册窗口
 *
 * 业务规则：
 *   1) 注册时密码需要二次输入，且两次一致才提交；
 *   2) 登录成功后把 User 对象传给 MainFrame；
 *   3) 默认管理员账号 admin / admin123。
 */
public class LoginFrame extends JFrame {

    private final JTextField usernameField = new JTextField(15);
    private final JPasswordField passwordField = new JPasswordField(15);
    private final JPasswordField passwordConfirmField = new JPasswordField(15);

    public LoginFrame() {
        setTitle("红色文化打卡系统 - 登录");
        setSize(420, 360);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(new java.awt.Color(0xB22222));
        top.setPreferredSize(new Dimension(420, 70));
        JLabel title = new JLabel("红色文化打卡系统 V3", JLabel.CENTER);
        title.setFont(new Font("微软雅黑", Font.BOLD, 22));
        title.setForeground(java.awt.Color.WHITE);
        top.add(title, BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);

        // 卡片：登录 / 注册
        JPanel center = new JPanel(new BorderLayout());
        center.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        // 登录区
        JPanel loginForm = new JPanel(new GridLayout(2, 2, 10, 10));
        loginForm.add(new JLabel("用户名："));
        loginForm.add(usernameField);
        loginForm.add(new JLabel("密码："));
        loginForm.add(passwordField);

        // 注册区表单字段
        JTextField regUsername = new JTextField(15);
        JPasswordField regPwd = new JPasswordField(15);
        JPasswordField regPwd2 = new JPasswordField(15);
        JPanel regForm2 = new JPanel(new GridLayout(3, 2, 10, 10));
        regForm2.add(new JLabel("用户名："));
        regForm2.add(regUsername);
        regForm2.add(new JLabel("密码："));
        regForm2.add(regPwd);
        regForm2.add(new JLabel("确认密码："));
        regForm2.add(regPwd2);

        // 标签卡片
        javax.swing.JTabbedPane tabs = new javax.swing.JTabbedPane();
        tabs.addTab("登录", loginForm);
        tabs.addTab("注册", regForm2);

        center.add(tabs, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        // 底部按钮区
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton actionBtn = new JButton("登录");
        actionBtn.setPreferredSize(new Dimension(110, 36));
        bottom.add(actionBtn);

        // 切换 tab 时改按钮文案
        tabs.addChangeListener(e -> actionBtn.setText(tabs.getSelectedIndex() == 0 ? "登录" : "注册"));

        actionBtn.addActionListener(e -> {
            int idx = tabs.getSelectedIndex();
            if (idx == 0) {
                doLogin();
            } else {
                doRegister(regUsername, regPwd, regPwd2);
            }
        });
        add(bottom, BorderLayout.SOUTH);
    }

    /** 登录 */
    private void doLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        if (username.isEmpty() || password.isEmpty()) {
            UIUtil.warn(this, "请输入用户名和密码");
            return;
        }
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.USER_LOGIN)
                    .param("username", username)
                    .param("password", password);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return (User) resp.getData();
        }, user -> {
            UIUtil.info(this, "登录成功，欢迎 " + user.getUsername());
            openMainFrame(user);
        });
    }

    /** 注册 */
    private void doRegister(JTextField unField, JPasswordField p1Field, JPasswordField p2Field) {
        String username = unField.getText().trim();
        String pwd1 = new String(p1Field.getPassword()).trim();
        String pwd2 = new String(p2Field.getPassword()).trim();
        if (username.isEmpty() || pwd1.isEmpty() || pwd2.isEmpty()) {
            UIUtil.warn(this, "请完整填写注册信息");
            return;
        }
        if (!pwd1.equals(pwd2)) {
            UIUtil.warn(this, "两次输入的密码不一致");
            return;
        }

        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.USER_REGISTER)
                    .param("username", username)
                    .param("password", pwd1);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return resp;
        }, resp -> {
            UIUtil.info(this, "注册成功，请使用新账号登录");
            // 把用户名回填到登录框
            usernameField.setText(username);
        });
    }

    /** 打开主窗口，关闭登录窗口 */
    private void openMainFrame(User user) {
        SwingUtilities.invokeLater(() -> {
            MainFrame main = new MainFrame(user);
            main.setVisible(true);
            dispose();
        });
    }
}
