package com.redculture.ui;

import com.redculture.net.NetUtil;
import com.redculture.pojo.CheckinRecord;
import com.redculture.pojo.ScenicSpot;
import com.redculture.pojo.User;
import com.redculture.protocol.ActionType;
import com.redculture.protocol.Request;
import com.redculture.protocol.Response;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 打卡面板（V3 核心业务）
 *
 * 功能：
 *   1) 普通用户：查看自己的打卡记录，支持按景点 ID、记录 ID、关键字搜索；
 *   2) 管理员：查看全部打卡记录；
 *   3) 任意用户可发起打卡（选景点 + 心得），提交后积分 +1；
 *   4) 右键菜单：修改心得 / 删除打卡；删除后积分 -1，下限 0（服务端兜底）；
 *   5) 点击表头支持按列排序。
 */
public class CheckinPanel extends JPanel {

    private static final SimpleDateFormat DATE_FMT = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    private final User currentUser;
    private final DefaultTableModel tableModel;
    private final JTable table;
    private final TableRowSorter<DefaultTableModel> rowSorter;
    private final JTextField keywordField;
    private final JTextField spotIdField;

    public CheckinPanel(User user) {
        this.currentUser = user;
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        top.add(new JLabel("关键字："));
        keywordField = new JTextField(12);
        top.add(keywordField);
        top.add(new JLabel("景点ID："));
        spotIdField = new JTextField(6);
        top.add(spotIdField);
        JButton searchBtn = new JButton("搜索");
        searchBtn.addActionListener(e -> refresh());
        top.add(searchBtn);
        JButton resetBtn = new JButton("重置");
        resetBtn.addActionListener(e -> {
            keywordField.setText("");
            spotIdField.setText("");
            refresh();
        });
        top.add(resetBtn);
        top.add(new JLabel("    "));
        JButton checkinBtn = new JButton("去打卡");
        checkinBtn.addActionListener(e -> showCheckinDialog());
        top.add(checkinBtn);
        add(top, BorderLayout.NORTH);

        String[] cols = currentUser.isAdmin()
                ? new String[]{"编号", "用户", "景点ID", "景点名称", "心得", "打卡时间"}
                : new String[]{"编号", "景点ID", "景点名称", "心得", "打卡时间"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0 || (currentUser.isAdmin() && columnIndex == 2)
                        || (!currentUser.isAdmin() && columnIndex == 1)) {
                    return Integer.class;
                }
                return Object.class;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(26);
        table.getTableHeader().setReorderingAllowed(false);
        rowSorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(rowSorter);
        // 设置自动启动排序
        table.setAutoCreateRowSorter(false);

        // 右键菜单
        JPopupMenu popup = new JPopupMenu();
        javax.swing.JMenuItem editItem = new javax.swing.JMenuItem("修改心得");
        editItem.addActionListener(e -> editComment());
        popup.add(editItem);
        javax.swing.JMenuItem delItem = new javax.swing.JMenuItem("删除打卡");
        delItem.addActionListener(e -> deleteCheckin());
        popup.add(delItem);
        table.setComponentPopupMenu(popup);

        add(new JScrollPane(table), BorderLayout.CENTER);

        refresh();
    }

    public void refresh() {
        String keyword = keywordField.getText().trim();
        String spotIdText = spotIdField.getText().trim();
        Integer spotId = null;
        if (!spotIdText.isEmpty()) {
            try {
                spotId = Integer.parseInt(spotIdText);
            } catch (NumberFormatException nfe) {
                UIUtil.warn(this, "景点ID 必须为数字");
                return;
            }
        }
        final Integer spotIdFinal = spotId;
        UIUtil.runAsync(this, () -> {
            Request req;
            if (currentUser.isAdmin()) {
                req = new Request(ActionType.CHECKIN_LIST_ALL).param("keyword", keyword);
            } else {
                req = new Request(ActionType.CHECKIN_LIST_BY_USER)
                        .param("userId", currentUser.getId())
                        .param("keyword", keyword)
                        .param("spotId", spotIdFinal);
            }
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            @SuppressWarnings("unchecked")
            List<CheckinRecord> list = (List<CheckinRecord>) resp.getData();
            return list;
        }, this::renderTable);
    }

    private void renderTable(List<CheckinRecord> list) {
        tableModel.setRowCount(0);
        if (list == null) {
            return;
        }
        for (CheckinRecord c : list) {
            if (currentUser.isAdmin()) {
                tableModel.addRow(new Object[]{
                        c.getId(),
                        c.getUsername(),
                        c.getSpotId(),
                        c.getSpotName(),
                        c.getComment(),
                        formatTime(c.getCheckinTime())
                });
            } else {
                tableModel.addRow(new Object[]{
                        c.getId(),
                        c.getSpotId(),
                        c.getSpotName(),
                        c.getComment(),
                        formatTime(c.getCheckinTime())
                });
            }
        }
    }

    /** 获取当前选中的记录 id（用于修改 / 删除） */
    private CheckinRecord selectedRecord() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            UIUtil.warn(this, "请先选择一行");
            return null;
        }
        int row = table.convertRowIndexToModel(viewRow);
        CheckinRecord c = new CheckinRecord();
        c.setId((int) tableModel.getValueAt(row, 0));
        if (currentUser.isAdmin()) {
            c.setComment((String) tableModel.getValueAt(row, 4));
        } else {
            c.setComment((String) tableModel.getValueAt(row, 3));
        }
        // admin 删除任意记录时也按记录所属用户扣分；这里我们用本记录的字段
        // 为简化，删除时通过单独请求 USER 信息不可行，改由服务端按记录所属 user 扣分
        // 这里仍传 currentUser 仅供 user 自己删除场景
        c.setUserId(currentUser.getId());
        return c;
    }

    /** 打卡弹窗 */
    private void showCheckinDialog() {
        JComboBox<ScenicSpot> spotBox = new JComboBox<>();
        DefaultComboBoxModel<ScenicSpot> spotModel = new DefaultComboBoxModel<>();
        spotBox.setModel(spotModel);
        JTextArea commentArea = new JTextArea(5, 25);
        commentArea.setLineWrap(true);

        JPanel form = new JPanel(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
        gbc.insets = new java.awt.Insets(4, 4, 4, 4);
        gbc.anchor = java.awt.GridBagConstraints.WEST;
        gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        form.add(new JLabel("选择景点："), gbc);
        gbc.gridx = 1;
        form.add(spotBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = java.awt.GridBagConstraints.NORTHWEST;
        form.add(new JLabel("打卡心得："), gbc);
        gbc.gridx = 1;
        form.add(new JScrollPane(commentArea), gbc);

        // 先加载景点下拉数据
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.SPOT_LIST).param("keyword", "");
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            @SuppressWarnings("unchecked")
            List<ScenicSpot> spots = (List<ScenicSpot>) resp.getData();
            return spots;
        }, spots -> {
            for (ScenicSpot s : spots) {
                spotModel.addElement(s);
            }
            // 数据就绪后再展示弹窗
            int result = JOptionPane.showConfirmDialog(this, form,
                    "新增打卡", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result != JOptionPane.OK_OPTION) {
                return;
            }
            ScenicSpot chosen = (ScenicSpot) spotBox.getSelectedItem();
            if (chosen == null) {
                UIUtil.warn(this, "请选择景点");
                return;
            }
            String comment = commentArea.getText().trim();
            submitCheckin(chosen.getId(), comment);
        });
    }

    private void submitCheckin(int spotId, String comment) {
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.CHECKIN_ADD)
                    .param("userId", currentUser.getId())
                    .param("spotId", spotId)
                    .param("comment", comment);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return resp;
        }, r -> {
            UIUtil.info(this, "打卡成功，积分 +1");
            refresh();
        });
    }

    /** 修改心得 */
    private void editComment() {
        CheckinRecord selected = selectedRecord();
        if (selected == null) {
            return;
        }
        JTextArea area = new JTextArea(6, 30);
        area.setLineWrap(true);
        area.setText(selected.getComment() == null ? "" : selected.getComment());
        Object[] options = {"确定", "取消"};
        int result = JOptionPane.showOptionDialog(this, new JScrollPane(area),
                "修改打卡心得", JOptionPane.YES_NO_OPTION,
                JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
        if (result != JOptionPane.YES_OPTION) {
            return;
        }
        String newComment = area.getText().trim();
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.CHECKIN_UPDATE_COMMENT)
                    .param("id", selected.getId())
                    .param("comment", newComment);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return resp;
        }, r -> {
            UIUtil.info(this, "修改心得成功");
            refresh();
        });
    }

    /** 删除打卡 */
    private void deleteCheckin() {
        CheckinRecord selected = selectedRecord();
        if (selected == null) {
            return;
        }
        if (!UIUtil.confirm(this, "确定删除该打卡记录？\n删除后积分 -1（积分下限 0）。")) {
            return;
        }
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.CHECKIN_DELETE)
                    .param("id", selected.getId())
                    .param("userId", currentUser.getId());
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            return resp;
        }, r -> {
            UIUtil.info(this, "删除成功，积分 -1");
            refresh();
        });
    }

    private String formatTime(Date date) {
        return date == null ? "" : DATE_FMT.format(date);
    }
}
