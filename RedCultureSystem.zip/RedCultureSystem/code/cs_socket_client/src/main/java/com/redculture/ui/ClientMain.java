package com.redculture.ui;

import com.redculture.net.NetUtil;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * V3 客户端启动入口
 *
 * 启动流程：
 *   1) 套用系统外观；
 *   2) 显示登录窗口；
 *   3) 登录成功后由 LoginFrame 切换到主窗口。
 *
 * 运行：java -jar redculture-v3-client.jar
 */
public class ClientMain {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException
                | IllegalAccessException | UnsupportedLookAndFeelException e) {
            // 静默回退默认 Metal 风格
        }

        SwingUtilities.invokeLater(() -> {
            try {
                NetUtil.connect();
            } catch (Exception e) {
                UIUtil.error(null, "无法连接服务端：" + NetUtil.getHost() + ":" + NetUtil.getPort()
                        + "\n请检查服务端是否启动，错误：" + e.getMessage());
            }
            LoginFrame frame = new LoginFrame();
            frame.setVisible(true);
        });
    }
}
