package com.redculture.ui;

import com.redculture.net.NetUtil;
import com.redculture.pojo.User;
import com.redculture.protocol.ActionType;
import com.redculture.protocol.Request;
import com.redculture.protocol.Response;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 用户列表面板（管理员专用）
 *
 * 功能：只读展示全部用户，展示角色、积分、注册时间。
 */
public class UserListPanel extends JPanel {

    private static final SimpleDateFormat DATE_FMT = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    private final DefaultTableModel tableModel;

    public UserListPanel() {
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        top.add(new JLabel("全部用户（管理员只读视图）"));
        JButton refreshBtn = new JButton("刷新");
        refreshBtn.addActionListener(e -> refresh());
        top.add(refreshBtn);
        add(top, BorderLayout.NORTH);

        String[] cols = {"编号", "用户名", "角色", "积分", "注册时间"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable table = new JTable(tableModel);
        table.setRowHeight(26);
        table.getTableHeader().setReorderingAllowed(false);
        add(new JScrollPane(table), BorderLayout.CENTER);

        refresh();
    }

    public void refresh() {
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.USER_LIST_ALL);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            @SuppressWarnings("unchecked")
            List<User> list = (List<User>) resp.getData();
            return list;
        }, this::renderTable);
    }

    private void renderTable(List<User> list) {
        tableModel.setRowCount(0);
        if (list == null) {
            return;
        }
        for (User u : list) {
            tableModel.addRow(new Object[]{
                    u.getId(),
                    u.getUsername(),
                    u.isAdmin() ? "管理员" : "普通用户",
                    u.getPoints(),
                    formatTime(u.getCreateTime())
            });
        }
    }

    private String formatTime(Date date) {
        return date == null ? "" : DATE_FMT.format(date);
    }
}
