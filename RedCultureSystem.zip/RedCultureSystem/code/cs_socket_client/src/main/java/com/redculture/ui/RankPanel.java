package com.redculture.ui;

import com.redculture.net.NetUtil;
import com.redculture.pojo.User;
import com.redculture.protocol.ActionType;
import com.redculture.protocol.Request;
import com.redculture.protocol.Response;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;

/**
 * 热门景点排行榜面板
 *
 * 功能：按打卡次数降序展示，并显示「热门景点」标记。
 */
public class RankPanel extends JPanel {

    private final User currentUser;
    private final DefaultTableModel tableModel;

    public RankPanel(User user) {
        this.currentUser = user;
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        top.add(new JLabel("热门景点排行榜（按打卡次数降序）"));
        JButton refreshBtn = new JButton("刷新");
        refreshBtn.addActionListener(e -> refresh());
        top.add(refreshBtn);
        add(top, BorderLayout.NORTH);

        String[] cols = {"排名", "景点名称", "打卡次数"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable table = new JTable(tableModel);
        table.setRowHeight(28);
        table.getTableHeader().setReorderingAllowed(false);
        add(new JScrollPane(table), BorderLayout.CENTER);

        refresh();
    }

    public void refresh() {
        UIUtil.runAsync(this, () -> {
            Request req = new Request(ActionType.CHECKIN_RANK);
            Response resp = NetUtil.send(req);
            if (!resp.isSuccess()) {
                throw new RuntimeException(resp.getMessage());
            }
            @SuppressWarnings("unchecked")
            List<Object[]> list = (List<Object[]>) resp.getData();
            return list;
        }, this::renderTable);
    }

    private void renderTable(List<Object[]> list) {
        tableModel.setRowCount(0);
        if (list == null) {
            return;
        }
        int rank = 1;
        for (Object[] row : list) {
            tableModel.addRow(new Object[]{rank++, row[0], row[1]});
        }
    }
}
